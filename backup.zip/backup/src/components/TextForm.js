import React, {useState} from 'react'



export default function TextForm(prop) {
    const [text, setText] = useState("Sample Text");
    const handleUppercase = ()=>{
            setText(text.toUpperCase())
    }

    const handleLowercase = ()=>{
        setText(text.toLowerCase())
}

    const handleOnChange = (event)=>{
        setText(event.target.value)
}
    
  return (
    <> 
   
<div className="mb-3">
    <h1>{prop.heading}</h1>
  <label htmlFor="myBox" className="form-label"></label>
  <textarea className="form-control" id="MyBox" rows="8" value={text} onChange={handleOnChange}></textarea>

  
</div>
<button className='btn btn-primary'  onClick={handleUppercase}> Convert to Uppercase</button>
<button className='btn btn-primary'  onClick={handleLowercase}> Convert to Uppercase</button>

<div className="container">
    <p>Text Summar</p>
    <div>{text.length} character</div>

    </div>
</>

  )
}
